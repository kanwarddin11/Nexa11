import { sql } from "drizzle-orm";
import { pgTable, text, varchar, serial, integer, timestamp, boolean } from "drizzle-orm/pg-core";
import { createInsertSchema } from "drizzle-zod";
import { z } from "zod";

export const users = pgTable("users", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  username: text("username").notNull().unique(),
  password: text("password").notNull(),
});

export const insertUserSchema = createInsertSchema(users).pick({
  username: true,
  password: true,
});

export type InsertUser = z.infer<typeof insertUserSchema>;
export type User = typeof users.$inferSelect;

export const verifications = pgTable("verifications", {
  id: serial("id").primaryKey(),
  inputText: text("input_text").notNull(),
  inputType: text("input_type").notNull().default("text"),
  originSource: text("origin_source"),
  verdict: text("verdict").notNull(),
  credibilityScore: integer("credibility_score").notNull(),
  summary: text("summary").notNull(),
  sources: text("sources").array().notNull().default(sql`'{}'::text[]`),
  claimsAnalyzed: text("claims_analyzed").array().notNull().default(sql`'{}'::text[]`),
  flaggedClaims: text("flagged_claims").array().notNull().default(sql`'{}'::text[]`),
  seoKeyword: text("seo_keyword"),
  isBookmarked: boolean("is_bookmarked").notNull().default(false),
  createdAt: timestamp("created_at").default(sql`CURRENT_TIMESTAMP`).notNull(),
});

export const insertVerificationSchema = createInsertSchema(verifications).omit({
  id: true,
  createdAt: true,
});

export type InsertVerification = z.infer<typeof insertVerificationSchema>;
export type Verification = typeof verifications.$inferSelect;

export const verifiedTools = pgTable("verified_tools", {
  id: serial("id").primaryKey(),
  name: text("name").notNull(),
  link: text("link").notNull(),
  clicks: integer("clicks").notNull().default(0),
  status: text("status").notNull().default("Verified"),
  logoUrl: text("logo_url"),
});

export const insertVerifiedToolSchema = createInsertSchema(verifiedTools).omit({
  id: true,
});

export type InsertVerifiedTool = z.infer<typeof insertVerifiedToolSchema>;
export type VerifiedTool = typeof verifiedTools.$inferSelect;

export const verifyRequestSchema = z.object({
  content: z.string().min(10, "Please provide at least 10 characters of content to verify."),
});

export type VerifyRequest = z.infer<typeof verifyRequestSchema>;
