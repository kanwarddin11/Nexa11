import { type Verification, type InsertVerification, verifications, type VerifiedTool, type InsertVerifiedTool, verifiedTools } from "@shared/schema";
import { db } from "./db";
import { eq, desc, sql, count } from "drizzle-orm";

export interface AdminStats {
  totalVerifications: number;
  averageScore: number;
  verdictBreakdown: { verdict: string; count: number }[];
  topKeywords: string[];
  recentActivity: { date: string; count: number }[];
}

export interface IStorage {
  createVerification(data: InsertVerification): Promise<Verification>;
  getVerifications(): Promise<Verification[]>;
  getVerification(id: number): Promise<Verification | undefined>;
  updateVerification(id: number, data: Partial<InsertVerification>): Promise<Verification | undefined>;
  deleteVerification(id: number): Promise<void>;
  getAdminStats(): Promise<AdminStats>;
  getVerifiedTools(): Promise<VerifiedTool[]>;
  createVerifiedTool(data: InsertVerifiedTool): Promise<VerifiedTool>;
  deleteVerifiedTool(id: number): Promise<void>;
  incrementToolClicks(id: number): Promise<VerifiedTool | undefined>;
  updateToolLogo(id: number, logoUrl: string): Promise<VerifiedTool | undefined>;
  addVerifiedTool(name: string, link: string): Promise<VerifiedTool>;
}

export class DatabaseStorage implements IStorage {
  async createVerification(data: InsertVerification): Promise<Verification> {
    const [v] = await db.insert(verifications).values(data).returning();
    return v;
  }

  async getVerifications(): Promise<Verification[]> {
    return db.select().from(verifications).orderBy(desc(verifications.createdAt));
  }

  async getVerification(id: number): Promise<Verification | undefined> {
    const [v] = await db.select().from(verifications).where(eq(verifications.id, id));
    return v;
  }

  async updateVerification(id: number, data: Partial<InsertVerification>): Promise<Verification | undefined> {
    const [v] = await db.update(verifications).set(data).where(eq(verifications.id, id)).returning();
    return v;
  }

  async deleteVerification(id: number): Promise<void> {
    await db.delete(verifications).where(eq(verifications.id, id));
  }

  async getAdminStats(): Promise<AdminStats> {
    const allVerifications = await db.select().from(verifications);
    const total = allVerifications.length;
    const avgScore = total > 0
      ? Math.round(allVerifications.reduce((sum, v) => sum + v.credibilityScore, 0) / total)
      : 0;

    const verdictMap = new Map<string, number>();
    const keywordMap = new Map<string, number>();
    const dateMap = new Map<string, number>();

    for (const v of allVerifications) {
      const normalizedVerdict = v.credibilityScore >= 80
        ? "Credible"
        : v.credibilityScore >= 60
        ? "Mostly True"
        : v.credibilityScore >= 40
        ? "Questionable"
        : "Likely False";
      verdictMap.set(normalizedVerdict, (verdictMap.get(normalizedVerdict) || 0) + 1);

      if (v.seoKeyword) {
        keywordMap.set(v.seoKeyword, (keywordMap.get(v.seoKeyword) || 0) + 1);
      }

      const date = new Date(v.createdAt).toISOString().split("T")[0];
      dateMap.set(date, (dateMap.get(date) || 0) + 1);
    }

    const verdictBreakdown = Array.from(verdictMap.entries())
      .map(([verdict, count]) => ({ verdict, count }))
      .sort((a, b) => b.count - a.count);

    const topKeywords = Array.from(keywordMap.entries())
      .sort((a, b) => b[1] - a[1])
      .slice(0, 10)
      .map(([k]) => k);

    if (topKeywords.length === 0) {
      topKeywords.push("AI Truth", "Fake News Detector", "NeXA AI", "Fact Check", "Verification");
    }

    const recentActivity = Array.from(dateMap.entries())
      .map(([date, count]) => ({ date, count }))
      .sort((a, b) => b.date.localeCompare(a.date))
      .slice(0, 14);

    return { totalVerifications: total, averageScore: avgScore, verdictBreakdown, topKeywords, recentActivity };
  }

  async getVerifiedTools(): Promise<VerifiedTool[]> {
    return db.select().from(verifiedTools);
  }

  async createVerifiedTool(data: InsertVerifiedTool): Promise<VerifiedTool> {
    const [t] = await db.insert(verifiedTools).values(data).returning();
    return t;
  }

  async deleteVerifiedTool(id: number): Promise<void> {
    await db.delete(verifiedTools).where(eq(verifiedTools.id, id));
  }

  async incrementToolClicks(id: number): Promise<VerifiedTool | undefined> {
    const [t] = await db
      .update(verifiedTools)
      .set({ clicks: sql`${verifiedTools.clicks} + 1` })
      .where(eq(verifiedTools.id, id))
      .returning();
    return t;
  }

  async updateToolLogo(id: number, logoUrl: string): Promise<VerifiedTool | undefined> {
    const [t] = await db
      .update(verifiedTools)
      .set({ logoUrl })
      .where(eq(verifiedTools.id, id))
      .returning();
    return t;
  }

  async addVerifiedTool(name: string, link: string): Promise<VerifiedTool> {
    const [t] = await db.insert(verifiedTools).values({ name, link }).returning();
    return t;
  }
}

export const storage = new DatabaseStorage();
